package com.assignment.myassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyAssignmentApplication.class, args);
	}

}
