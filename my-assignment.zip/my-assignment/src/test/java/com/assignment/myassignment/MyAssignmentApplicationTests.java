package com.assignment.myassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
